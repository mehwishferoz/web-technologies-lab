import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-book1-form',
  templateUrl: './book1-form.component.html',
  styleUrls: ['./book1-form.component.css']
})
export class Book1FormComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
